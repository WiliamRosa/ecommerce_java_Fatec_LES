package strategy.impl;

import java.math.BigDecimal;

import dominio.EntidadeDominio;
import dominio.venda.EnderecoEntrega;
import dominio.venda.Frete;

public class CalcularFreteEntrega extends AbstractValidador {
   
    @Override
    public String processar(EntidadeDominio entidade) {
        EnderecoEntrega endereco = (EnderecoEntrega) entidade;
        
        Frete frete = new Frete(endereco);
        
        
        frete.setValor(new BigDecimal("21.10"));
        frete.setPrazo(2);
        endereco.setFrete(frete);
        
        return null;
    }
   
}
