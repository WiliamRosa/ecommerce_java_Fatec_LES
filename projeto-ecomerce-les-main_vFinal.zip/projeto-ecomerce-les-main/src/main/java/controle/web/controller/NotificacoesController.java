package controle.web.controller;

import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/cli-notificacoes"})
public class NotificacoesController extends HttpServlet{
	private static final long serialVersionUID = 1L;
	
	protected void service(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
	    if(request.getRequestURI().equals("/EcomerceLivroLES/cli-notificacoes")) {
	        
            RequestDispatcher rd = request.getRequestDispatcher("/cli_notificacoes.jsp");
            
            try {
                rd.forward(request, response);
            } catch (ServletException | IOException e) {
                e.printStackTrace();
            }
             
	    } 
	}
	
}
